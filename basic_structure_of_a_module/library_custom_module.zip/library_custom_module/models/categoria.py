from odoo import models, fields

class Categoria (models.Model):
    _name = 'categoria'

    name = fields.Char(string='Categoria')
