{
    'name': 'Library Module',
    'summary': """
    Creating my first module.
    """,
    'author': 'Carlos',
    'category': 'General',
    'version': '1.0.0',
    'depends': [],
    'data': [
        'security/library_security.xml',
        'security/ir.model.access.csv',
        'views/menu_view.xml',
        # 'views/autor.xml',
        # 'views/categoria.xml',
        # 'views/libro.xml',
    ],
}
